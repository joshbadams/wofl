//
//  Utils.cpp
//  Wofl
//
//  Created by Josh on 2/4/13.
//  Copyright (c) 2013 Josh. All rights reserved.
//

#include "Utils.h"
#include "WoflMath.h"

WoflFile* Utils::File = NULL;
WoflInput* Utils::Input = NULL;
WoflPlatform* Utils::Platform = NULL;

WColor WColor::White = WColor(1,1,1,1);
WColor WColor::Black = WColor(0,0,0,1);
WColor WColor::Clear = WColor(0,0,0,0);
